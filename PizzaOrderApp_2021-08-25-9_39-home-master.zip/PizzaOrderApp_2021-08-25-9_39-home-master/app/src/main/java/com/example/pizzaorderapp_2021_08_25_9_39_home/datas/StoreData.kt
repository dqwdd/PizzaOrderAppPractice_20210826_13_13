package com.example.pizzaorderapp_2021_08_25_9_39_home.datas

import java.io.Serializable

class StoreData(val name : String, val PhoneNum : String, val LogoURL : String) : Serializable {

}