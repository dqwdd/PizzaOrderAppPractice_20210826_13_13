package com.neppplus.pizzaorderapp_20210825.datas

import java.io.Serializable

class StoreData(
    val name : String,
    val phoneNum : String,
    val logoURL: String) : Serializable {



}